

#项目基本介绍
*此项目为某个区域的地图的信息查询浏览的单页面应用程序
#使用框架
*knockout.js 版本：3.4.2
#bootstrap 版本：3.2.1
#使用的API
*Google Map API
#下载地址
*暂无






//街区信息的数据
      // Model 模型数据
var locations = [{
    title: '天安门广场',
    pinyin: 'Tian An Men Guang Chang',
    position: {
      lat: 39.9063748,
      lng: 116.3925044
    }
  },
  {
    title: '奥林匹克公园',
    pinyin: 'Ao Lin Pi Ke Gong Yuan',
    position: {
      lat: 39.9942851,
      lng: 116.3915031
    }
  },
  {
    title: '颐和园',
    pinyin: 'Yi He Yuan',
    position: {
      lat: 39.9892384,
      lng: 116.232084212
    }
  },
  {
    title: '大观园',
    pinyin: 'Da Guan Yuan',
    position: {
      lat: 39.8712889,
      lng: 116.353961517
    }
  },
  {
    title: '故宫博物院',
    pinyin: 'Gu Gong Bo Wu Yuan',
    position: {
      lat: 39.9101321,
      lng: 116.363471212
    }
  }
]
      
      /**
 * 侧边栏 ViewModel
 */
function AppViewModel() {
  var self = this;
  self.name = 'savo';
  self.filter = ko.observable('');
  self.siderVisible = ko.observable(true);

  /**
   * 动态绑定地址列表
   */
  self.filteredLots = ko.computed(function () {
    var res = locations.filter(function (lot) {
      return lot.title.toLowerCase().indexOf(self.filter().toLowerCase()) > -1;
    });
    // 更新地图信息
    // updateMarkers(res);
    return res;
  });

  /**
   * 切换侧边栏
   */
  self.toggleSider = function () {
    self.siderVisible(!self.siderVisible());
  }

  /**
   * 点击地点高亮地图上的标记
   */
  self.markLot = function (lot) {
    google.maps.event.trigger(markers[locations.indexOf(lot)], 'click');
  }
}

/**
 * app 初始化函数，Google JS回调调用
 */
function appInit() {
  initMap();
  ko.applyBindings(new AppViewModel());
}



      var map,infowindow,bounds;

      var markers=[];
      /*
      *初始化地图
      */
      function initMap() {
      	infowindow = new google.maps.InfoWindow();
  		bounds = new google.maps.LatLngBounds();
        map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: {lat: 39.9101321, lng: 116.363471212}
        });
        var defaultIcon = makeMarkerIcon('0091ff');
        var highlightedIcon = makeMarkerIcon('FFFF24');
        //将街区数据的信息绑定到地图对应的点上
        for (var i = 0; i <locations.length; i++) {
        	var position=locations[i].position;
        	var title=locations[i].title;
        	var marker=new google.maps.Marker({
        		map:map,
        		position:position,
        		title:title,
        		animation:google.maps.Animation.Drop,
        		icon: defaultIcon,
        		id:i
        	});
        	markers.push(marker);
        	
        	marker.addListener('click',function(){
        		populateInfoWindow(this,infowindow);
        	})
        	marker.addListener('mouseover', function() {
           	 	this.setIcon(highlightedIcon);
         	});
          	marker.addListener('mouseout', function() {
            	this.setIcon(defaultIcon);
          	});
        	bounds.extend(markers[i].position);
        } 
        map.fitBounds(bounds);
      }
      //地点的信息窗口显示的信息
      function populateInfoWindow(marker,infowindow){
      	if(infowindow.marker!=marker){
      		infowindow.marker=marker;
      		infowindow.setContent('<div>'+marker.title+'</div>');
      		infowindow.open(map,marker);
      		infowindow.addListener('closeclick',function(){
      			infowindow.setMarker=null;
      		})


      	}
      }
      //为标记设置特定颜色
	  function makeMarkerIcon(markerColor) {
        var markerImage = new google.maps.MarkerImage(
          'http://chart.googleapis.com/chart?chst=d_map_spin&chld=1.15|0|'+ markerColor +
          '|40|_|%E2%80%A2',
          new google.maps.Size(21, 34),
          new google.maps.Point(0, 0),
          new google.maps.Point(10, 34),
          new google.maps.Size(21,34));
        return markerImage;
      }


      function mapError() {
  		alert('Google Map initialized Error');
	 }